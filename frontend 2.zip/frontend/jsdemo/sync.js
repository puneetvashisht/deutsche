console.log('starting...');

var foo = function(){
    console.log('This is a function');
    return "success"
}
var result = foo();
console.log(result);

console.log('finishing...');