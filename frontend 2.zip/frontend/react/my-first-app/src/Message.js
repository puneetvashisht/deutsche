function Message () {
    return (
        <div>
            <h1>Message Component</h1>
        </div>
    )
}
export default Message;