package com.dte.spring_boot_jpa_demo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaDemo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
