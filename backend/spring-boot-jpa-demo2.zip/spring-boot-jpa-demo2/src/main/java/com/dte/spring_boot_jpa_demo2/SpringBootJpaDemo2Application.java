package com.dte.spring_boot_jpa_demo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaDemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaDemo2Application.class, args);
	}

}
