const About = () => {
    return (
        <div>
            <h2>About Page</h2>
            <p>This is the about page. Click the navigation links to navigate between pages.</p>
        </div>
    );
};
export default About;